# revenues_war_budget_2020_2026.R
# D. Tatarinov's part
# Presentation question: How did the war change the budget of Ukraine?
# Focus of this file: revenue side of the state budget, 2020-2026
#
# Main revenue-side argument:
# The full-scale war changed not only the nominal size of state budget revenues,
# but also their structure. After 2021, the budget became larger in hryvnia terms,
# while non-tax revenues and international support became much more visible.
#
# Important limitation:
# 2020-2025 files cover January-December.
# 2026 file covers January-March only.
# So 2026 should be treated as latest available partial-year data,
# not as a full-year observation.

library(tidyverse)

# =============================================================================
# 1. KSE palette
# =============================================================================

kse_palette <- c(
  navy = "#003964",
  cyan = "#00BBCE",
  green = "#A7C539",
  red = "#F15B43",
  dark_red = "#D33E2C",
  yellow = "#E4E541"
)

# =============================================================================
# 2. File list
# =============================================================================

income_files <- tibble(
  file_year = c(2020, 2021, 2022, 2023, 2024, 2025, 2026),
  period_months = c(12, 12, 12, 12, 12, 12, 3),
  period_label = c(
    "2020",
    "2021",
    "2022",
    "2023",
    "2024",
    "2025",
    "2026\nJan-Mar"
  ),
  is_partial = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE),
  file_path = c(
    "INC-NAT-2020-1-12.csv",
    "INC-NAT-2021-1-12.csv",
    "INC-NAT-2022-1-12.csv",
    "INC-NAT-2023-1-12.csv",
    "INC-NAT-2024-1-12.csv",
    "INC-NAT-2025-1-12.csv",
    "INC-NAT-2026-1-3.csv"
  )
)

# =============================================================================
# 3. Load all files
# =============================================================================

read_income_file <- function(file_path, file_year, period_months, period_label, is_partial) {
  inc_raw <- read.csv(
    file_path,
    sep = ";",
    stringsAsFactors = FALSE,
    fileEncoding = "Windows-1251"
  )

  # The first row in these OpenBudget files is usually technical / duplicated
  # metadata. We remove it to keep actual observations.
  inc_raw <- inc_raw[-1, ]

  inc_raw |>
    mutate(
      year = file_year,
      period_months = period_months,
      period_label = period_label,
      is_partial = is_partial
    )
}

inc_raw_all <- pmap_dfr(income_files, read_income_file)

# Quick checks
names(inc_raw_all)
head(inc_raw_all)

# =============================================================================
# 4. Clean names and convert numeric columns
# =============================================================================

to_number <- function(x) {
  x <- as.character(x)
  x <- str_replace_all(x, fixed("\u00A0"), "")
  x <- str_replace_all(x, "\\s+", "")
  x <- str_replace_all(x, ",", ".")
  x <- na_if(x, "")
  as.numeric(x)
}

inc_all <- inc_raw_all |>
  rename(
    fund_type = тип.фонду,
    code = код,
    name = найменування.коду,
    initial_annual_plan = початковий.річний.план,
    adjusted_annual_plan = уточнений.річний.план,
    adjusted_period_plan = уточнений.план.за.період,
    executed_period = виконано.за.період,
    deviation_period = відхилення.до.уточненого.плану.за.період,
    execution_rate_period = відсоток.виконання.до.уточненого.плану.за.період,
    execution_rate_annual = відсоток.виконання.до.уточненого.річного.плану
  ) |>
  mutate(
    code = as.character(code),
    year = as.integer(year),
    period_months = as.integer(period_months),
    is_partial = as.logical(is_partial),
    across(
      c(
        initial_annual_plan,
        adjusted_annual_plan,
        adjusted_period_plan,
        executed_period,
        deviation_period,
        execution_rate_period,
        execution_rate_annual
      ),
      to_number
    )
  ) |>
  # Keep only normal budget rows.
  # Some rows can be continuation lines from long names. fund_type == TOTAL
  # keeps the useful national-level rows.
  filter(fund_type == "TOTAL" | code == "0000000")

# Total state budget revenue rows
inc_total <- inc_all |>
  filter(code == "0000000")

# Category rows, excluding total all-zero codes
inc_categories <- inc_all |>
  filter(!code %in% c("0000", "0000000", "00000000"))

# Quick checks
glimpse(inc_total)
glimpse(inc_categories)

inc_total |>
  select(year, period_label, adjusted_annual_plan, executed_period, execution_rate_annual)

# =============================================================================
# 5. Shorter labels for plotting
# =============================================================================

short_income_name <- function(x) {
  x_short <- case_when(
    str_detect(x, "Податок на додану вартість з ввезених") ~ "ПДВ з імпорту",
    str_detect(x, "Податок на додану вартість з вироблених") ~ "ПДВ з вітчизняних товарів",
    str_detect(x, "Податок та збір на доходи фізичних осіб") ~ "ПДФО",
    str_detect(x, "Податок на прибуток підприємств") ~ "Податок на прибуток",
    str_detect(x, "Податки на доходи, податки на прибуток") ~ "Податки на доходи та прибуток",
    str_detect(x, "Внутрішні податки на товари та послуги") ~ "Внутрішні податки на товари та послуги",
    str_detect(x, "Неподаткові надходження") ~ "Неподаткові надходження",
    str_detect(x, "Від Європейського Союзу") ~ "ЄС, іноземні уряди та міжнародні організації",
    str_detect(x, "Надходження в рамках програм допомоги") ~ "Допомога ЄС та міжнародних партнерів",
    str_detect(x, "^Гранти \\(дарунки\\)") ~ "Гранти (усі рівні)",
    str_detect(x, "Гранти на бюджетну підтримку") ~ "Гранти на бюджетну підтримку",
    str_detect(x, "Власні надходження бюджетних установ") ~ "Власні надходження бюджетних установ",
    str_detect(x, "Частина чистого прибутку") ~ "Частина прибутку і дивіденди",
    str_detect(x, "Цільові фонди") ~ "Цільові фонди",
    str_detect(x, "RELINK|RELINC") ~ "Грант МБРР\n(RELINK)",
    str_detect(x, "ARISE") ~ "Грант МБРР\n(ARISE)",
    TRUE ~ x
  )

  str_wrap(x_short, width = 32)
}

# =============================================================================
# 6. Chart 1: Total executed revenues, 2020-2026
# =============================================================================
# Chart type: line chart with points
#
# War-related insight:
# State budget revenues increased strongly in nominal hryvnia terms after 2021.
# This suggests that the fiscal scale of the state expanded during wartime.
#
# Careful wording:
# This does not mean that the state simply became "richer", because inflation
# also increases nominal hryvnia values. The chart shows nominal budget scale.

total_revenue <- inc_total |>
  mutate(
    executed_bln = executed_period / 1e9,
    year_type = if_else(is_partial, "Partial year", "Full year")
  )

ggplot(total_revenue, aes(
  x = year,
  y = executed_bln
)) +
  geom_line(
    data = total_revenue |> filter(!is_partial),
    color = kse_palette[["navy"]],
    linewidth = 1.2
  ) +
  geom_point(
    aes(color = year_type),
    size = 3.5
  ) +
  geom_text(
    aes(label = round(executed_bln, 1)),
    vjust = -2,
    size = 3.1,
    color = "black"
  ) +
  scale_color_manual(
    values = c(
      "Full year" = kse_palette[["navy"]],
      "Partial year" = kse_palette[["yellow"]]
    )
  ) +
  scale_x_continuous(breaks = 2020:2026) +
  labs(
    title = "Executed state budget revenues, 2020-2026",
    subtitle = "2026 covers January-March only, so it is shown as partial-year data",
    x = NULL,
    y = "Executed amount, billion UAH",
    color = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    legend.position = "top"
  ) +
  expand_limits(y = max(total_revenue$executed_bln, na.rm = TRUE) * 1.12)

# =============================================================================
# 7. Prepare broad revenue structure
# =============================================================================

# These are broad top-level revenue groups.
# We use exact top-level budget codes to avoid double-counting subcategories.
broad_structure <- inc_categories |>
  mutate(
    broad_group = case_when(
      code == "10000000" ~ "Tax revenues",
      code == "20000000" ~ "Non-tax revenues",
      code == "30000000" ~ "Capital revenues",
      code == "40000000" ~ "Transfers / international support",
      code == "50000000" ~ "Target funds",
      TRUE ~ NA_character_
    )
  ) |>
  filter(!is.na(broad_group)) |>
  group_by(year, period_label, is_partial, broad_group) |>
  summarise(
    executed_bln = sum(executed_period, na.rm = TRUE) / 1e9,
    .groups = "drop"
  )

broad_structure_shares <- broad_structure |>
  group_by(year, period_label, is_partial) |>
  mutate(
    total_bln = sum(executed_bln, na.rm = TRUE),
    share = 100 * executed_bln / total_bln
  ) |>
  ungroup()

# =============================================================================
# 8. Chart 2: Revenue structure by shares, 2020-2025
# =============================================================================
# Insight:
# This chart shows how the structure of revenues changed across the years.
#
# Interpretation idea:
# Tax revenues remain a core part of the state budget, but after 2022
# non-tax revenues and external support / transfers become much more visible
# in the revenue structure.

broad_structure <- inc_categories |>
  mutate(
    broad_group = case_when(
      code == "10000000" ~ "Tax revenues",
      code == "20000000" ~ "Non-tax revenues",
      code == "30000000" ~ "Capital revenues",
      code %in% c("41000000", "42000000") ~ "Transfers / international support",
      code == "50000000" ~ "Target funds",
      TRUE ~ NA_character_
    )
  ) |>
  filter(!is.na(broad_group)) |>
  group_by(year, period_label, is_partial, broad_group) |>
  summarise(
    executed_bln = sum(executed_period, na.rm = TRUE) / 1e9,
    .groups = "drop"
  ) |>
  mutate(
    year_plot = factor(period_label, levels = unique(total_revenue$period_label))
  )

ggplot(broad_structure, aes(
  x = year_plot,
  y = executed_bln,
  fill = broad_group
)) +
  geom_col() +
  scale_fill_manual(
    values = c(
      "Tax revenues" = kse_palette[["navy"]],
      "Non-tax revenues" = kse_palette[["cyan"]],
      "Transfers / international support" = kse_palette[["green"]],
      "Capital revenues" = kse_palette[["yellow"]],
      "Target funds" = kse_palette[["red"]]
    )
  ) +
  labs(
    title = "Structure of state budget revenues",
    subtitle = "Executed amount by broad revenue groups",
    x = NULL,
    y = "Executed amount, billion UAH",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    legend.position = "bottom"
  )

# Recalculate shares after Chart 2 broad groups are defined.
# This keeps the final structure_share_table consistent with the stacked bar chart.
broad_structure_shares <- broad_structure |>
  group_by(year, period_label, is_partial) |>
  mutate(
    total_bln = sum(executed_bln, na.rm = TRUE),
    share = 100 * executed_bln / total_bln
  ) |>
  ungroup()

# =============================================================================
# 10. Chart 3: Adjusted annual plan vs executed amount by year
# =============================================================================
# Chart type: grouped bar plot
#
# War-related insight:
# During wartime, revenue planning became more uncertain.
# In 2023-2024, executed revenues exceeded adjusted annual plans, while 2025
# was below 100% execution.
#
# Careful wording:
# Do not say that the war alone caused overexecution. It may reflect inflation,
# emergency revisions, external inflows, or stronger-than-expected collections.
# For 2026, execution is January-March only, while the plan is annual.

plan_vs_actual_year <- inc_total |>
  mutate(
    year_plot = factor(period_label, levels = period_label),
    adjusted_annual_plan_bln = adjusted_annual_plan / 1e9,
    executed_period_bln = executed_period / 1e9
  ) |>
  select(year_plot, adjusted_annual_plan_bln, executed_period_bln) |>
  pivot_longer(
    cols = c(adjusted_annual_plan_bln, executed_period_bln),
    names_to = "indicator",
    values_to = "amount_bln"
  ) |>
  mutate(
    indicator = recode(
      indicator,
      adjusted_annual_plan_bln = "Adjusted annual plan",
      executed_period_bln = "Executed amount"
    )
  )

ggplot(plan_vs_actual_year, aes(
  x = year_plot,
  y = amount_bln,
  fill = indicator
)) +
  geom_col(position = "dodge") +
  scale_fill_manual(
    values = c(
      "Adjusted annual plan" = kse_palette[["cyan"]],
      "Executed amount" = kse_palette[["green"]]
    )
  ) +
  geom_text(
    aes(label = round(amount_bln, 1)),
    position = position_dodge(width = 0.9),
    vjust = -1,
    size = 3.1,
    color = "black") +
  labs(
    title = "Adjusted annual plan vs executed amount",
    subtitle = "2026 execution is January-March only; the plan is annual",
    x = NULL,
    y = "Amount, billion UAH",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    legend.position = "top"
  )

# =============================================================================
# 11. Chart 4: Top categories in the latest available period
# =============================================================================
# Chart type: lollipop plot
#
# War-related insight:
# This is not the main 2020-2026 war evidence.
# It is a latest-snapshot chart showing what currently drives revenue collection.
# Since 2026 is partial-year data, this should be presented as the latest
# available picture, not as a full-year result.

latest_year <- max(inc_categories$year, na.rm = TRUE)
latest_label <- inc_categories |>
  filter(year == latest_year) |>
  distinct(period_label) |>
  pull(period_label)

top_executed_latest <- inc_categories |>
  filter(
    year == latest_year,
    executed_period > 0
  ) |>
  arrange(desc(executed_period)) |>
  slice_head(n = 8) |>
  mutate(
    name_short = short_income_name(name),
    name_plot = if_else(
      duplicated(name_short) | duplicated(name_short, fromLast = TRUE),
      paste0(name_short, "\n[", code, "]"),
      name_short
    ),
    executed_bln = executed_period / 1e9
  ) |>
  arrange(executed_bln) |>
  mutate(name_plot = factor(name_plot, levels = name_plot))

ggplot(top_executed_latest, aes(x = executed_bln, y = name_plot)) +
  geom_segment(
    aes(x = 0, xend = executed_bln, y = name_plot, yend = name_plot),
    color = kse_palette[["cyan"]],
    linewidth = 1.2
  ) +
  geom_point(
    color = kse_palette[["navy"]],
    size = 4
  ) +
  geom_text(
    aes(label = round(executed_bln, 1)),
    hjust = -0.3,
    size = 3.5,
    color = "black"
  ) +
  labs(
    title = paste0("Top revenue categories in ", latest_label),
    subtitle = "Executed amount in the latest available period",
    x = "Amount, billion UAH",
    y = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.y = element_text(size = 9),
    panel.grid.minor = element_blank()
  ) +
  expand_limits(x = max(top_executed_latest$executed_bln, na.rm = TRUE) * 1.15)

# =============================================================================
# 12. Optional diagnostic chart: Lowest execution rates in latest period
# =============================================================================
# Chart type: horizontal bar plot
#
# This chart is weaker for the main question "How did the war change the budget?"
# It is more technical. Use it only if you need an extra slide.
#
# Interpretation idea:
# In the 2026 file, low values are expected for many items because the year is
# only partly completed. Values below 1 mean less than 1% of the adjusted annual
# plan has been executed so far.

low_execution_latest <- inc_categories |>
  filter(
    year == latest_year,
    adjusted_annual_plan > 1e9,
    !is.na(execution_rate_annual)
  ) |>
  arrange(execution_rate_annual) |>
  slice_head(n = 10) |>
  mutate(
    name_plot = case_when(
      str_detect(name, "Цільові фонди") ~ "Цільові фонди",
      str_detect(name, "Частина чистого прибутку") ~ "Частина прибутку\nі дивіденди",
      str_detect(name, "логістичної інфраструктури|мережевого сполучення|Відновлення критично") ~ "Грант МБРР\nRELINK",
      str_detect(name, "Податки і збори, не віднесені") ~ "Інші податки\nі збори",
      str_detect(name, "Кошти, що перераховуються Національним банком") ~ "Перерахування\nНБУ",
      str_detect(name, "Інші підакцизні товари") ~ "Інші підакцизні\nтовари",
      str_detect(name, "Інша допомога, надана Європейським Союзом") ~ "Інша допомога\nЄС",
      str_detect(name, "Надходження в рамках програм допомоги") ~ "Допомога ЄС та\nміжнародних партнерів",
      str_detect(name, "ARISE") ~ "Грант МБРР\nARISE",
      str_detect(name, "Відсотки, нараховані за користування") ~ "Відсотки за\nкредитом",
      TRUE ~ str_wrap(name, width = 18)
    ),
    name_plot = factor(name_plot, levels = rev(name_plot)),
    rate_label = round(execution_rate_annual, 1)
  )

ggplot(low_execution_latest, aes(
  x = name_plot,
  y = execution_rate_annual
)) +
  geom_col(fill = kse_palette[["red"]]) +
  geom_text(
    aes(label = rate_label),
    hjust = -0.15,
    size = 3.5,
    color = "black"
  ) +
  coord_flip() +
  labs(
    title = paste0("Lowest annual execution rates in ", latest_label),
    subtitle = "Only categories with adjusted annual plan above 1 billion UAH",
    x = NULL,
    y = "% of adjusted annual plan executed"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    axis.text.y = element_text(size = 9),
    panel.grid.minor = element_blank()
  ) +
  expand_limits(y = max(low_execution_latest$execution_rate_annual, na.rm = TRUE) * 1.25)

# =============================================================================
# 13. Summary tables for writing findings
# =============================================================================

summary_revenue_by_year <- inc_total |>
  transmute(
    year,
    period_label,
    is_partial,
    adjusted_annual_plan_bln = adjusted_annual_plan / 1e9,
    executed_bln = executed_period / 1e9,
    execution_rate_annual
  )

summary_revenue_by_year

structure_share_table <- broad_structure_shares |>
  filter(!is_partial) |>
  select(year, broad_group, share) |>
  pivot_wider(
    names_from = broad_group,
    values_from = share
  )

structure_share_table

# Suggested slide conclusion:
# "The revenue side of Ukraine's state budget changed after the full-scale
# invasion. Nominal executed revenues grew strongly after 2021, but this should
# be read with inflation in mind. The more important change is structural:
# tax revenues became a smaller share of the budget, while non-tax revenues and
# transfers / international support became much more visible. This suggests that
# the wartime budget became more dependent on extraordinary and external sources
# of revenue."
