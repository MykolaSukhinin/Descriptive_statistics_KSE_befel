# ============================================================
# UKRAINE REGIONAL BUDGET ANALYSIS
# Research question: How did the war change regional budgets?
# Graphs: Gini (1), Heatmap (2), Map 2024 (3), Map change (4)
# ============================================================

library(tidyverse)
library(ineq)
library(showtext)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)

font_add_google("Roboto", "roboto")
showtext_auto()

# Створи папку якщо немає
dir.create("assets/charts", recursive = TRUE, showWarnings = FALSE)


# ============================================================
# 1. LOAD DATA
# ============================================================

df_raw <- read_delim(
  "boost_1.csv",
  delim  = ";",
  locale = locale(encoding = "windows-1251")
)

df_regions <- df_raw %>%
  filter(
    ADMIN1 == "Місцеві бюджети",
    !is.na(ADMIN2), ADMIN2 != "",
    is.na(FUNC1) | FUNC1 == ""
  ) %>%
  select(region = ADMIN2,
         `2018_EXECUTED`, `2018_ADJUSTED`,
         `2019_EXECUTED`, `2019_ADJUSTED`,
         `2020_EXECUTED`, `2020_ADJUSTED`,
         `2021_EXECUTED`, `2021_ADJUSTED`,
         `2022_EXECUTED`, `2022_ADJUSTED`,
         `2023_EXECUTED`, `2023_ADJUSTED`,
         `2024_EXECUTED`, `2024_ADJUSTED`,
         `2025_EXECUTED`, `2025_ADJUSTED`)

df_long <- df_regions %>%
  pivot_longer(
    cols      = -region,
    names_to  = c("year", "type"),
    names_sep = "_",
    values_to = "amount"
  ) %>%
  mutate(
    year       = as.integer(year),
    amount_bln = amount / 1e9
  )

df_exec <- df_long %>% filter(type == "EXECUTED")
df_plan <- df_long %>% filter(type == "ADJUSTED")


# ============================================================
# 2. POPULATION + PER CAPITA
# ============================================================

population <- tibble(
  region  = c("Вінницька обл.", "Волинська обл.", "Дніпропетровська обл.",
              "Донецька обл.", "Житомирська обл.", "Закарпатська обл.",
              "Запорiзька обл.", "Івано-Франкiвська обл.", "Київська обл.",
              "Кіровоградська обл.", "Луганська обл.", "Львiвська обл.",
              "м. Київ", "Миколаївська обл.", "Одеська обл.",
              "Полтавська обл.", "Рiвненська обл.", "Сумська обл.",
              "Тернопільська обл.", "Харківська обл.", "Херсонська обл.",
              "Хмельницька обл.", "Черкаська обл.", "Чернiвецька обл.",
              "Чернігівська обл."),
  pop_mln = c(1.53, 1.03, 3.17, 4.17, 1.20, 1.26, 1.70, 1.37, 1.78,
              0.93, 2.15, 2.52, 2.96, 1.12, 2.39, 1.39, 1.16, 1.07,
              1.04, 2.67, 1.03, 1.26, 1.20, 0.90, 0.98)
)

df_pc <- df_exec %>%
  left_join(population, by = "region") %>%
  mutate(per_capita = (amount / 1e6) / pop_mln)


# ============================================================
# 3. REGION NAME MAPPING
# ============================================================

region_en <- c(
  "Вінницька обл."         = "Vinnytsya",
  "Волинська обл."         = "Volyn",
  "Дніпропетровська обл."  = "Dnipropetrovs'k",
  "Донецька обл."          = "Donets'k",
  "Житомирська обл."       = "Zhytomyr",
  "Закарпатська обл."      = "Transcarpathia",
  "Запорiзька обл."        = "Zaporizhzhya",
  "Івано-Франкiвська обл." = "Ivano-Frankivs'k",
  "Київська обл."          = "Kiev",
  "Кіровоградська обл."    = "Kirovohrad",
  "Луганська обл."         = "Luhans'k",
  "Львiвська обл."         = "L'viv",
  "м. Київ"                = "Kiev City",
  "Миколаївська обл."      = "Mykolayiv",
  "Одеська обл."           = "Odessa",
  "Полтавська обл."        = "Poltava",
  "Рiвненська обл."        = "Rivne",
  "Сумська обл."           = "Sumy",
  "Тернопільська обл."     = "Ternopil'",
  "Харківська обл."        = "Kharkiv",
  "Херсонська обл."        = "Kherson",
  "Хмельницька обл."       = "Khmel'nyts'kyy",
  "Черкаська обл."         = "Cherkasy",
  "Чернiвецька обл."       = "Chernivtsi",
  "Чернігівська обл."      = "Chernihiv"
)

df_pc   <- df_pc   %>% mutate(region_en = recode(region, !!!region_en))
df_exec <- df_exec %>% mutate(region_en = recode(region, !!!region_en))
df_plan <- df_plan %>% mutate(region_en = recode(region, !!!region_en))


# ============================================================
# 4. BUILD MAP (Ukraine + Crimea)
# ============================================================

ukraine_map   <- ne_states(country = "Ukraine", returnclass = "sf")
russia_states <- ne_states(country = "Russia",  returnclass = "sf")
crimea        <- russia_states %>% filter(name == "Crimea")
ukraine_map_full <- bind_rows(ukraine_map, crimea)


# ============================================================
# GRAPH 1 (Slide 06): Gini coefficient 2018-2025
# ============================================================

gini_data <- df_pc %>%
  filter(year >= 2018, year <= 2025) %>%
  group_by(year) %>%
  summarise(gini = Gini(per_capita, na.rm = TRUE))

graph1 <- ggplot(gini_data, aes(x = year, y = gini)) +
  geom_line(color = "#003964", linewidth = 1.4) +
  geom_point(color = "#F15B43", size = 4) +
  geom_vline(xintercept = 2022, linetype = "dashed",
             color = "#F15B43", linewidth = 0.9) +
  annotate("text", x = 2022.1, y = max(gini_data$gini) * 0.99,
           label = "Full-scale war", hjust = 0, size = 4,
           color = "#F15B43", fontface = "bold") +
  scale_x_continuous(breaks = 2018:2025) +
  labs(
    title    = "Inequality in regional budget spending (Gini index)",
    subtitle = "Higher = more unequal distribution across regions",
    x        = NULL,
    y        = "Gini coefficient",
    caption  = "Source: openbudget.gov.ua"
  ) +
  theme_minimal(base_size = 13, base_family = "roboto") +
  theme(panel.grid.minor = element_blank())

graph1
ggsave("assets/charts/graph1_gini.png", graph1, width = 8, height = 5, dpi = 200)


# ============================================================
# GRAPH 2 (Slide 07): Heatmap — budget execution rate
# ============================================================

df_exec_rate <- df_exec %>%
  left_join(
    df_plan %>% select(region_en, year, planned = amount_bln),
    by = c("region_en", "year")
  ) %>%
  filter(year >= 2018, year <= 2025) %>%
  mutate(
    exec_rate = round(amount_bln / planned * 100, 1),
    exec_rate = pmin(exec_rate, 150)
  )

graph2 <- ggplot(df_exec_rate,
                 aes(x = factor(year),
                     y = reorder(region_en, exec_rate),
                     fill = exec_rate)) +
  geom_tile(color = "white", linewidth = 0.4) +
  geom_text(aes(label = round(exec_rate)), size = 2.8, color = "black") +
  scale_fill_gradient2(
    low      = "#D85A30",
    mid      = "lightyellow",
    high     = "#1D9E75",
    midpoint = 100,
    name     = "Execution %"
  ) +
  labs(
    title    = "Budget execution rate by region (2018–2025)",
    subtitle = "Actual spending as % of planned | Red = underexecution | Capped at 150%",
    x        = NULL,
    y        = NULL,
    caption  = "Source: openbudget.gov.ua"
  ) +
  theme_minimal(base_size = 11, base_family = "roboto") +
  theme(
    legend.position = "right",
    panel.grid      = element_blank()
  )

graph2
ggsave("assets/charts/graph2_heatmap.png", graph2, width = 11, height = 8, dpi = 200)


# ============================================================
# GRAPH 3 (Slide 08a): Map — spending per capita 2024
# ============================================================

map_data_2024 <- ukraine_map_full %>%
  left_join(
    df_pc %>% filter(year == 2024) %>% select(region_en, per_capita),
    by = c("name" = "region_en")
  )

graph3 <- ggplot(map_data_2024) +
  geom_sf(aes(fill = per_capita / 1000), color = "white", linewidth = 0.3) +
  scale_fill_gradient(
    low      = "#E6F1FB",
    high     = "#0C447C",
    name     = "UAH thousands\nper capita",
    na.value = "grey80"
  ) +
  annotate("text",
           x = 34.0, y = 45.3,
           label    = "Crimea\n(occupied,\nno data)",
           size     = 2.8,
           color    = "grey40",
           fontface = "italic") +
  labs(
    title    = "Local budget spending per capita by region (2024)",
    subtitle = "UAH thousands per person | Grey = no data available",
    caption  = "Source: openbudget.gov.ua | Crimea shown without data (occupied territory)"
  ) +
  theme_void(base_family = "roboto") +
  theme(
    plot.title      = element_text(size = 14, margin = margin(b = 4)),
    plot.subtitle   = element_text(size = 11, color = "grey40"),
    legend.position = "right"
  )

graph3
ggsave("assets/charts/graph3_map_2024.png", graph3, width = 10, height = 6, dpi = 200)


# ============================================================
# GRAPH 4 (Slide 08b): Map — % change 2021 vs 2025
# ============================================================

df_change <- df_pc %>%
  filter(year %in% c(2021, 2025)) %>%
  select(region_en, year, per_capita) %>%
  pivot_wider(
    names_from   = year,
    values_from  = per_capita,
    names_prefix = "y"
  ) %>%
  mutate(pct_change = round((y2025 - y2021) / y2021 * 100, 1))

map_data_change <- ukraine_map_full %>%
  left_join(df_change, by = c("name" = "region_en"))

graph4 <- ggplot(map_data_change) +
  geom_sf(aes(fill = pct_change), color = "white", linewidth = 0.3) +
  scale_fill_gradient2(
    low      = "#D85A30",
    mid      = "lightyellow",
    high     = "#1D9E75",
    midpoint = 0,
    name     = "Change %",
    na.value = "grey80"
  ) +
  annotate("text",
           x = 34.0, y = 45.3,
           label    = "Crimea\n(occupied,\nno data)",
           size     = 2.8,
           color    = "grey40",
           fontface = "italic") +
  labs(
    title    = "Change in per capita spending: 2021 vs 2025 (%)",
    subtitle = "Green = increased | Red = decreased (occupied / frontline regions)",
    caption  = "Source: openbudget.gov.ua | Crimea shown without data (occupied territory)"
  ) +
  theme_void(base_family = "roboto") +
  theme(
    plot.title      = element_text(size = 14, margin = margin(b = 4)),
    plot.subtitle   = element_text(size = 11, color = "grey40"),
    legend.position = "right"
  )

graph4
ggsave("assets/charts/graph4_map_change.png", graph4, width = 10, height = 6, dpi = 200)


cat("Done! Saved to assets/charts/:\n")
cat("  graph1_gini.png\n")
cat("  graph2_heatmap.png\n")
cat("  graph3_map_2024.png\n")
cat("  graph4_map_change.png\n")
