library(tidyverse)
library(readr)
library(stringr)
library(scales)
library(ragg)

kse <- list(
  navy = "#003964",
  cyan = "#00BBCE",
  lime = "#A7C539",
  coral = "#F15B43",
  yellow = "#FFD200",
  ink = "#172033",
  gray = "#7A869A",
  light = "#EEF6FB"
)

dir.create("assets/charts", recursive = TRUE, showWarnings = FALSE)
dir.create("data/prepared", recursive = TRUE, showWarnings = FALSE)

theme_kse <- function(base_size = 15) {
  theme_minimal(base_size = base_size) +
    theme(
      text = element_text(color = kse$ink),
      plot.title = element_text(color = kse$navy, face = "bold", size = base_size + 5),
      plot.subtitle = element_text(color = "#526071", size = base_size),
      axis.title = element_text(color = kse$navy, face = "bold"),
      axis.text = element_text(color = kse$ink),
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      panel.grid.major.y = element_line(color = "#D9E6EF", linewidth = 0.35),
      legend.title = element_blank(),
      legend.text = element_text(size = base_size - 1),
      legend.position = "bottom",
      plot.margin = margin(12, 18, 12, 18)
    )
}

save_plot <- function(plot, filename, width = 11, height = 6.4) {
  ggsave(
    filename = file.path("assets/charts", filename),
    plot = plot,
    device = ragg::agg_png,
    width = width,
    height = height,
    dpi = 180,
    bg = "white"
  )
}

read_revenue <- function(path) {
  year <- str_extract(basename(path), "20\\d{2}") |> as.integer()
  period <- if_else(str_detect(basename(path), "1-3"), "Jan-Mar", "Jan-Dec")

  # Some source files contain unquoted line breaks in long Ukrainian names.
  # The summary rows we use are well-formed, so parsing warnings can be suppressed.
  suppressWarnings(read_delim(
    path,
    delim = ";",
    skip = 1,
    locale = locale(encoding = "CP1251"),
    col_types = cols(.default = col_character()),
    show_col_types = FALSE
  )) |>
    mutate(
      year = year,
      period = period,
      across(
        c(
          yearBeginPlan, yearCorrectionPlan, periodCorrectionPlan, periodDone,
          deviationToPeriodCorrectionPlan, percentDoneToPeriodCorrectionPlan,
          percentDoneToYearCorrectionPlan
        ),
        ~ suppressWarnings(parse_number(.x, locale = locale(decimal_mark = ".")))
      )
    )
}

revenue_files <- list.files(
  "data/raw/national_revenue",
  pattern = "^INC-NAT-.*\\.csv$",
  full.names = TRUE
)

revenue_raw <- map_dfr(revenue_files, read_revenue)

category_lookup <- tribble(
  ~incomeCode, ~category,
  "10000000", "Tax revenues",
  "20000000", "Non-tax revenues",
  "30000000", "Capital revenues",
  "41000000", "Transfers from governments",
  "42000000", "International grants",
  "50000000", "Target funds"
)

revenue_summary <- revenue_raw |>
  filter(incomeCode %in% c("0000000", category_lookup$incomeCode)) |>
  mutate(amount_buah = coalesce(periodDone, 0) / 1e9) |>
  left_join(category_lookup, by = "incomeCode") |>
  mutate(category = if_else(incomeCode == "0000000", "Total revenue", category)) |>
  select(year, period, incomeCode, category, amount_buah)

revenue_wide <- revenue_summary |>
  filter(category != "Total revenue") |>
  mutate(category = recode(
    category,
    "Transfers from governments" = "Official transfers",
    "International grants" = "Official transfers"
  )) |>
  group_by(year, period, category) |>
  summarise(amount_buah = sum(amount_buah, na.rm = TRUE), .groups = "drop") |>
  pivot_wider(names_from = category, values_from = amount_buah, values_fill = 0) |>
  left_join(
    revenue_summary |>
      filter(category == "Total revenue") |>
      select(year, total_revenue_buah = amount_buah),
    by = "year"
  ) |>
  mutate(
    domestic_revenue_buah = total_revenue_buah - `Official transfers`,
    revenue_label = if_else(period == "Jan-Mar", "partial-year actual", "actual")
  )

write_csv(revenue_summary, "data/prepared/revenue_composition.csv")
write_csv(revenue_wide, "data/prepared/revenue_summary.csv")

totals <- read_csv("data/prepared/national_totals.csv", show_col_types = FALSE)
functions <- read_csv("data/prepared/functional_shares.csv", show_col_types = FALSE)
crowding <- read_csv("data/prepared/crowding_out_2021_2025.csv", show_col_types = FALSE)
revisions <- read_csv("data/prepared/revisions_2022_top.csv", show_col_types = FALSE)
financing <- read_csv("data/prepared/financing_summary.csv", show_col_types = FALSE)
local_growth <- read_csv("data/prepared/local_budget_growth_2021_2025.csv", show_col_types = FALSE)
local_groups <- read_csv("data/prepared/local_budget_group_growth.csv", show_col_types = FALSE)

budget_equation <- totals |>
  filter(year >= 2020, year <= 2025) |>
  select(year, expenditure_buah = chart_value_buah) |>
  left_join(revenue_wide |> select(year, total_revenue_buah), by = "year") |>
  left_join(financing |> select(year, internal_buah, external_buah), by = "year") |>
  pivot_longer(
    c(total_revenue_buah, internal_buah, external_buah),
    names_to = "source",
    values_to = "amount_buah"
  ) |>
  mutate(source = recode(
    source,
    total_revenue_buah = "Revenue",
    internal_buah = "Internal financing",
    external_buah = "External financing"
  ),
  source = factor(source, levels = c("Revenue", "Internal financing", "External financing")))

budget_equation_totals <- budget_equation |>
  group_by(year) |>
  summarise(total_sources = sum(amount_buah, na.rm = TRUE), .groups = "drop")

p_budget_equation <- ggplot(budget_equation, aes(factor(year), amount_buah, fill = source)) +
  geom_col(width = 0.7, color = "white", linewidth = 0.25) +
  geom_text(
    data = filter(budget_equation, amount_buah >= 180),
    aes(label = label_number(accuracy = 1, big.mark = ",")(amount_buah)),
    position = position_stack(vjust = 0.5),
    color = "white",
    fontface = "bold",
    size = 5
  ) +
  geom_text(
    data = budget_equation_totals,
    aes(factor(year), total_sources, label = paste0(label_number(accuracy = 1, big.mark = ",")(total_sources), " bn")),
    inherit.aes = FALSE,
    vjust = -0.45,
    color = kse$navy,
    fontface = "bold",
    size = 5
  ) +
  scale_fill_manual(values = c("Revenue" = kse$cyan, "Internal financing" = kse$lime, "External financing" = kse$navy)) +
  scale_y_continuous(labels = label_number(big.mark = ","), expand = expansion(mult = c(0, 0.12))) +
  labs(
    title = "The budget equation changed",
    subtitle = "Revenue grew, but wartime gaps were increasingly closed by external financing.",
    x = NULL,
    y = "UAH bn"
  ) +
  theme_kse()
save_plot(p_budget_equation, "budget_equation.png")

p_total_expenditure <- totals |>
  filter(year <= 2025) |>
  ggplot(aes(factor(year), chart_value_buah, fill = year >= 2022)) +
  geom_col(width = 0.72, color = "white") +
  geom_text(
    aes(label = label_number(accuracy = 1, big.mark = ",")(chart_value_buah)),
    vjust = -0.35,
    color = kse$navy,
    fontface = "bold",
    size = 5
  ) +
  geom_vline(xintercept = 4.5, linetype = "dashed", color = kse$coral, linewidth = 1) +
  annotate("text", x = 4.62, y = 5750, label = "Full-scale\ninvasion", hjust = 0, color = kse$coral, fontface = "bold", size = 5) +
  scale_fill_manual(values = c("FALSE" = kse$cyan, "TRUE" = kse$navy), labels = c("Pre-war", "Wartime")) +
  scale_y_continuous(labels = label_number(big.mark = ","), expand = expansion(mult = c(0, 0.12))) +
  labs(
    title = "Spending moved to a new wartime scale",
    subtitle = "Nominal expenditure rose from UAH 1,490 bn in 2021 to UAH 5,474 bn in 2025.",
    x = NULL,
    y = "UAH bn"
  ) +
  theme_kse()
save_plot(p_total_expenditure, "total_expenditure.png")

function_order <- c(
  "Defense", "Public order, security & justice", "Social protection", "Health",
  "Education", "Economic affairs", "General public functions", "Housing & utilities",
  "Culture & sport", "Environment"
)
function_palette <- c(
  "Defense" = kse$navy,
  "Public order, security & justice" = "#0057B8",
  "Social protection" = "#00AEEF",
  "Health" = "#00B386",
  "Education" = kse$yellow,
  "Economic affairs" = "#F59E0B",
  "General public functions" = "#8A94A6",
  "Housing & utilities" = "#7DD3FC",
  "Culture & sport" = "#7C3AED",
  "Environment" = "#84CC16"
)

p_function_structure <- functions |>
  filter(year %in% c(2021, 2022, 2023, 2024, 2025)) |>
  mutate(function_en = factor(function_en, levels = function_order)) |>
  ggplot(aes(factor(year), share_pct, fill = function_en)) +
  geom_col(color = "white", linewidth = 0.18) +
  scale_fill_manual(values = function_palette, drop = FALSE) +
  labs(
    title = "The structure shifted from development functions to defense",
    subtitle = "By 2025, defense and security absorbed most state budget expenditure.",
    x = NULL,
    y = "Share of expenditure, %"
  ) +
  theme_kse(base_size = 14) +
  theme(legend.position = "right")
save_plot(p_function_structure, "functional_structure.png")

main_items <- functions |>
  filter(year %in% c(2021, 2025), function_en %in% function_order) |>
  select(year, function_en, amount_buah) |>
  pivot_wider(names_from = year, values_from = amount_buah, names_prefix = "y") |>
  filter(y2021 >= 50 | y2025 >= 50) |>
  mutate(
    change_x = y2025 / y2021,
    function_en = fct_reorder(function_en, y2025)
  )

p_main_items <- main_items |>
  ggplot(aes(y = function_en)) +
  geom_segment(aes(x = y2021, xend = y2025, yend = function_en), color = "#AAB7C4", linewidth = 1.1) +
  geom_point(aes(x = y2021, color = "2021"), size = 4.2) +
  geom_point(aes(x = y2025, color = "2025"), size = 4.2) +
  geom_text(
    aes(x = y2025, label = paste0("x", label_number(accuracy = 0.1)(change_x))),
    hjust = -0.12,
    color = kse$navy,
    fontface = "bold",
    size = 5
  ) +
  scale_color_manual(values = c("2021" = kse$cyan, "2025" = kse$navy)) +
  scale_x_continuous(labels = label_number(big.mark = ","), expand = expansion(mult = c(0.02, 0.18))) +
  labs(
    title = "The largest budget items changed by very different multiples",
    subtitle = "Points compare 2021 and 2025; labels show how many times each function changed.",
    x = "UAH bn",
    y = NULL
  ) +
  theme_kse()
save_plot(p_main_items, "main_items_2021_2025.png")

p_crowding <- crowding |>
  mutate(
    function_en = fct_reorder(function_en, change_pp),
    direction = if_else(change_pp >= 0, "Gained share", "Lost share")
  ) |>
  ggplot(aes(change_pp, function_en, fill = direction)) +
  geom_col(width = 0.75) +
  geom_vline(xintercept = 0, color = "#AAB7C4") +
  scale_fill_manual(values = c("Gained share" = kse$navy, "Lost share" = kse$coral)) +
  labs(
    title = "Defense gained share; civilian functions lost relative weight",
    subtitle = "Share change is measured in percentage points, 2025 minus 2021.",
    x = "Change in expenditure share, pp",
    y = NULL
  ) +
  theme_kse()
save_plot(p_crowding, "crowding_out.png")

p_revisions <- revisions |>
  slice_max(abs(revision_buah), n = 12) |>
  mutate(
    program_short = fct_reorder(program_short, revision_buah),
    direction = if_else(revision_buah >= 0, "Increased", "Reduced")
  ) |>
  ggplot(aes(revision_buah, program_short, fill = direction)) +
  geom_col() +
  geom_vline(xintercept = 0, color = "#AAB7C4") +
  scale_fill_manual(values = c("Increased" = kse$navy, "Reduced" = kse$coral)) +
  labs(
    title = "The 2022 plan was rewritten toward immediate wartime needs",
    subtitle = "Largest corrected-plan changes after the full-scale invasion.",
    x = "Change from initial to corrected plan, UAH bn",
    y = NULL
  ) +
  theme_kse(base_size = 10.5)
save_plot(p_revisions, "revisions_2022.png", height = 7)

p_financing_mix <- financing |>
  filter(year >= 2020, year <= 2025) |>
  select(year, Internal = internal_buah, External = external_buah) |>
  pivot_longer(-year, names_to = "source", values_to = "amount_buah") |>
  ggplot(aes(factor(year), amount_buah, fill = source)) +
  geom_col(color = "white", linewidth = 0.25) +
  scale_fill_manual(values = c("Internal" = kse$cyan, "External" = kse$navy)) +
  scale_y_continuous(labels = label_number(big.mark = ",")) +
  labs(
    title = "External financing became central to wartime budgeting",
    subtitle = "The financing mix moved away from domestic borrowing after 2022.",
    x = NULL,
    y = "UAH bn"
  ) +
  theme_kse()
save_plot(p_financing_mix, "financing_mix.png")

pressure <- totals |>
  filter(year >= 2020, year <= 2025) |>
  select(year, expenditure_buah = chart_value_buah) |>
  left_join(financing |> select(year, financing_buah = total_buah, external_buah), by = "year") |>
  arrange(year) |>
  mutate(
    expenditure_change = expenditure_buah - lag(expenditure_buah),
    financing_change = financing_buah - lag(financing_buah),
    external_change = external_buah - lag(external_buah)
  ) |>
  filter(!is.na(expenditure_change))

p_pressure <- pressure |>
  pivot_longer(c(expenditure_change, financing_change, external_change), names_to = "series", values_to = "amount_buah") |>
  mutate(series = recode(
    series,
    expenditure_change = "Expenditure increase",
    financing_change = "Net financing increase",
    external_change = "External financing increase"
  )) |>
  ggplot(aes(factor(year), amount_buah, fill = series)) +
  geom_col(position = position_dodge(width = 0.76), width = 0.68) +
  geom_hline(yintercept = 0, color = "#AAB7C4") +
  scale_fill_manual(values = c(
    "Expenditure increase" = kse$coral,
    "Net financing increase" = kse$navy,
    "External financing increase" = kse$cyan
  )) +
  scale_y_continuous(labels = label_number(big.mark = ",")) +
  labs(
    title = "Financing moved with spending pressure, especially in 2022-2023",
    subtitle = "Year-over-year changes show how the funding need jumped with wartime expenditure.",
    x = NULL,
    y = "Annual change, UAH bn"
  ) +
  theme_kse()
save_plot(p_pressure, "financing_vs_spending_pressure.png")

p_coverage <- totals |>
  filter(year >= 2018, year <= 2025) |>
  select(year, expenditure_buah = chart_value_buah) |>
  left_join(revenue_wide |> select(year, total_revenue_buah), by = "year") |>
  mutate(coverage_pct = total_revenue_buah / expenditure_buah * 100) |>
  ggplot(aes(year, coverage_pct)) +
  geom_hline(yintercept = 100, color = "#AAB7C4", linetype = "dashed") +
  geom_line(color = kse$navy, linewidth = 1.15) +
  geom_point(color = kse$coral, size = 3) +
  scale_y_continuous(labels = label_number(suffix = "%")) +
  labs(
    title = "Revenues no longer covered spending after the invasion",
    subtitle = "The coverage ratio fell from 87% in 2021 to about 70% in 2025.",
    x = NULL,
    y = "Revenue / expenditure"
  ) +
  theme_kse()
save_plot(p_coverage, "revenue_expenditure_coverage.png")

revenue_comp <- revenue_summary |>
  filter(year >= 2018, year <= 2025, category != "Total revenue") |>
  mutate(category = recode(
    category,
    "Transfers from governments" = "Official transfers",
    "International grants" = "Official transfers"
  )) |>
  group_by(year, category) |>
  summarise(amount_buah = sum(amount_buah, na.rm = TRUE), .groups = "drop") |>
  group_by(year) |>
  mutate(share = amount_buah / sum(amount_buah) * 100) |>
  ungroup() |>
  filter(category %in% c("Tax revenues", "Non-tax revenues", "Official transfers", "Capital revenues", "Target funds"))

p_revenue_comp <- revenue_comp |>
  ggplot(aes(factor(year), share, fill = category)) +
  geom_col(color = "white", linewidth = 0.2) +
  scale_fill_manual(values = c(
    "Tax revenues" = kse$navy,
    "Non-tax revenues" = kse$cyan,
    "Official transfers" = kse$coral,
    "Capital revenues" = kse$lime,
    "Target funds" = kse$yellow
  )) +
  labs(
    title = "Revenue composition also changed under wartime conditions",
    subtitle = "International grants and other transfers became visible parts of the revenue side.",
    x = NULL,
    y = "Share of revenue, %"
  ) +
  theme_kse()
save_plot(p_revenue_comp, "revenue_composition.png")

p_revenue_sources <- revenue_summary |>
  filter(year %in% c(2021, 2025), category != "Total revenue") |>
  mutate(category = recode(
    category,
    "Transfers from governments" = "Official transfers",
    "International grants" = "Official transfers"
  )) |>
  group_by(year, category) |>
  summarise(amount_buah = sum(amount_buah, na.rm = TRUE), .groups = "drop") |>
  filter(amount_buah > 1) |>
  ggplot(aes(amount_buah, fct_reorder(category, amount_buah), fill = factor(year))) +
  geom_col(position = position_dodge(width = 0.75), width = 0.68) +
  scale_fill_manual(values = c("2021" = kse$cyan, "2025" = kse$navy)) +
  scale_x_continuous(labels = label_number(big.mark = ",")) +
  labs(
    title = "Tax revenue grew, but grants/transfers became part of the story",
    subtitle = "Main revenue categories in 2021 and 2025.",
    x = "UAH bn",
    y = NULL
  ) +
  theme_kse()
save_plot(p_revenue_sources, "revenue_sources_2021_2025.png")

p_local_groups <- local_groups |>
  mutate(region_group = factor(region_group, levels = c("Frontline / near-front", "Other regions", "Western & rear benchmark"))) |>
  ggplot(aes(avg_growth, region_group, fill = region_group)) +
  geom_col(width = 0.62) +
  scale_x_continuous(labels = percent) +
  scale_fill_manual(values = c(
    "Frontline / near-front" = kse$coral,
    "Other regions" = kse$gray,
    "Western & rear benchmark" = kse$cyan
  )) +
  labs(
    title = "Frontline local budgets grew much less than rear benchmarks",
    subtitle = "Average local-budget expenditure growth, 2021 to 2025.",
    x = "Average growth",
    y = NULL
  ) +
  theme_kse()
save_plot(p_local_groups, "local_budget_groups.png")

p_local_regions <- local_growth |>
  mutate(
    admin2 = fct_reorder(admin2, growth_2021_2025),
    region_group = factor(region_group, levels = c("Frontline / near-front", "Other regions", "Western & rear benchmark"))
  ) |>
  ggplot(aes(growth_2021_2025, admin2, color = region_group)) +
  geom_point(size = 2.7) +
  geom_vline(xintercept = 0, color = "#AAB7C4") +
  scale_x_continuous(labels = percent) +
  scale_color_manual(values = c(
    "Frontline / near-front" = kse$coral,
    "Other regions" = kse$gray,
    "Western & rear benchmark" = kse$cyan
  )) +
  labs(
    title = "Regional effects were uneven",
    subtitle = "Each point is an oblast-level local budget; grouping is an analytical assumption.",
    x = "Growth of local budget expenditures, 2021 to 2025",
    y = NULL
  ) +
  theme_kse(base_size = 10.5) +
  theme(legend.position = "bottom")
save_plot(p_local_regions, "local_budget_growth.png", height = 7)

message("Charts and prepared revenue files rebuilt.")
